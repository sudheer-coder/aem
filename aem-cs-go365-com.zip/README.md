# Introduction 
TODO: Give a short introduction of your project. Let this section explain the objectives or the motivation behind this project. 

# Getting Started
TODO: Guide users through getting your code up and running on their own system. In this section you can talk about:
1.	Installation process
2.	Software dependencies
3.	Latest releases
4.	API references

# Build and Test
TODO: Describe and show how to build your code and run the tests. 

# Contribute
TODO: Explain how other users and developers can contribute to make your code better. 

If you want to learn more about creating good readme files then refer the following [guidelines](https://docs.microsoft.com/en-us/azure/devops/repos/git/create-a-readme?view=azure-devops). You can also seek inspiration from the below readme files:
- [ASP.NET Core](https://github.com/aspnet/Home)
- [Visual Studio Code](https://github.com/Microsoft/vscode)
- [Chakra Core](https://github.com/Microsoft/ChakraCore)

# Dispatcher Changes (needed for a new tenant)

# Vhost Files

1. available_vhosts (/src/conf.d/available_vhosts/)
Please refer to the file added in /dispatcher/src/conf.d/available_vhosts/aem_(tenant_name)_publish.vhost. Please replace (tenant_name) with the actual tenant (website\domain) name.
Also, replace <tenant_name> with the actual tenant (website\domain) name inside the contents of the file.

2. enabled_vhosts (/src/conf.d/enabled_vhosts/)
Please ensure that the enabled vhosts file is a .symlink and not an actual file. This must be generated either while cloning the repo or on your windows machine. 
Please follow the guide [here](https://dev.azure.com/humana/Customer%20Experience%20Management/_wiki/wikis/Customer-Experience-Management.wiki/13884/Checkout-dispatcher-repo) to generate the enabled_vhosts symlinks. 

NOTE: Enabled vhosts file added here /dispatcher/src/conf.d/enabled_vhosts/aem_(tenant_name)_publish.vhost is only for reference and is not a symlink. This file must be generated as explained above.

# Rewrites (/src/conf.d/rewrites/)
Please refer /dispatcher/src/conf.d/rewrites/(tenant_name)_rewrite.rules. Please replace (tenant_name) with the actual tenant (website\domain) name.

# Variables (/src/conf.d/variables/)
Please refer /dispatcher/src/conf.d/variables/custom.vars. Tenant specific variables can be defined here in this file. For instance CONTENT_FOLDER_NAME has been defined with <tenant_name> replace this with actual tenant. 
This variable is used in (tenant_name)_rewrite.rules

# Farm Files

1. available_farms (/dispatcher/src/conf.dispatcher.d/available_farms/)
Please refer /dispatcher/src/conf.dispatcher.d/available_farms/(tenant_name).farm. Please replace (tenant_name) with the actual tenant (website\domain) name.
Also, replace <tenant_name> with the actual tenant (website\domain) name inside the contents of the file.

2. enabled_farms (/src/conf.dispatcher.d/enabled_farms/)
Please ensure that the enabled farms file is a .symlink and not an actual file. This must be generated either while cloning the repo or on your windows machine. 
Please follow the guide [here](https://dev.azure.com/humana/Customer%20Experience%20Management/_wiki/wikis/Customer-Experience-Management.wiki/13884/Checkout-dispatcher-repo) to generate the enabled_farms symlink. 

NOTE: Enabled farms file added here /dispatcher/src/conf.dispatcher.d/enabled_farms/(tenant_name).farm is only for reference and is not a symlink. This file must be generated as explained above.

# Filters (/src/conf.dispatcher.d/filters/)
Please refer the file /dispatcher/src/conf.dispatcher.d/filters/(tenant_name).any and replace (tenant_name) with the actual tenant (website\domain) name.
Also, replace <tenant_name> with the actual tenant (website\domain) name inside the contents of the file if found any.

# Virtualhosts (/src/conf.dispatcher.d/virtualhosts/)
Please refer /dispatcher/src/conf.dispatcher.d/virtualhosts/virtualhosts.any and add your tenant specific virstual host names. Here in this example "dev-aemcspublish.<tenant_name>.com" is used please replace with an appropriate tenant name.


# Repository Initializer or RepoInit (ui.config/src/main/content/jcr_root/apps/<project-name>/osgiconfig/config/)
A set of configuration files which will be used to create folders, users and groups.
These files will be placed under ui.config/src/main/content/jcr_root/apps/<project-name>/osgiconfig/config/* 
and should be updated based on tenant requirement. Remove the configuration files that are not required.
Please refer to the Wiki Documentation for more Details [here](https://dev.azure.com/humana/Customer%20Experience%20Management/_wiki/wikis/Customer-Experience-Management.wiki/15509/AEMaaCS-Repo-Init-Scripts)

The list of Repository Initializer files are listed below:
* `org.apache.sling.jcr.repoinit.RepositoryInitializer~humana-new-tenant.cfg.json` Responsible for creating the content folder, templates, conf folder for the new tenant.
* `org.apache.sling.jcr.repoinit.RepositoryInitializer~humana-new-tenant-campaign.cfg.json`  Creates the Campaign path for the new Tenant.
* `org.apache.sling.jcr.repoinit.RepositoryInitializer~humana-new-tenant-content-fragments.cfg.json` Creates the content fragment folder in dam for the Tenant.
* `org.apache.sling.jcr.repoinit.RepositoryInitializer~humana-new-tenant-dam.cfg.json` Create the dam Asset folders and sets the appropriate properties related to the Tenant.
* `org.apache.sling.jcr.repoinit.RepositoryInitializer~humana-new-tenant-dam-projects.cfg.json` Create the dam Asset folders for the new Tenant.
* `org.apache.sling.jcr.repoinit.RepositoryInitializer~humana-new-tenant-experience-fragments.cfg.json` creates the experience fragment and the related conf folder for the Tenant.
* `org.apache.sling.jcr.repoinit.RepositoryInitializer~humana-new-tenant-groups.cfg.json` Creates Groups relates to Author. Super Author and developers.
* `org.apache.sling.jcr.repoinit.RepositoryInitializer~humana-new-tenant-tags.cfg.json` Creates the Tenant related Tags folder and sets the required properties.

Note: The above configuration need to target the different run modes (e.g. author, publish) or environments (e.g. dev, stage, prod).

# PARENT POM:
Parent pom is the main pom that is defined inside the .mvn folder of each tenant repo and the cs-all repo as well, this file defines all the common dependencies and their versions and also the profiles that are used across the projects. This concept is used to maintain consistency between the projects to use the common versions of the dependencies and to avoid errors in the build pipeline and also to avoid usage of deprecated dependencies.

How tenants can leverage the parent pom for building code and using dependencies:
In the main pom.xml of the tenant repo the below snippet code should be added so as to leverage the parent pom and should not add any profiles or any dependencies in their main pom.xml until and unless they want to use a dependency only specific to their project or a different version for a specific dependency.

	<parent>
		<groupId>com.humana.aem</groupId>
		<artifactId>aemaacs.parent</artifactId>
		<version>1.0.2</version>
		<relativePath>../.mvn/repository/com/humana/aem/aemaacs.parent/1.0.2/aemaacs.parent-1.0.2.pom</relativePath>
	</parent>

When building the code locally for a repo, any one of the below strategies should be followed for a successful build:

1.	RelativePath in the main pom.xml of the tenant should be replaced by “.mvn/repository/com/humana/aem/aemaacs.parent/1.0.2/aemaacs.parent-1.0.2.pom”
2.	.mvn folder should be copy and pasted parallel to the project for a successful local build.

If there is any addition of a new dependency or the change in the version of any existing dependency it is always advisable to change the version number of parent pom in the repo - https://dev.azure.com/humana/Customer%20Experience%20Management/_git/aem-cs

Once it is changed, a pipeline is triggered to create a new version folder and add a new version pom file inside the .mvn folder of the aem-cs-all repo - https://dev.azure.com/humana/Customer%20Experience%20Management/_git/aem-cs-all

Once the new version is created, it is the responsibility of each tenant to upgrade the version number in the main pom.xml to point to the latest parent pom changes whenever they are ready to start using the new versions or the new dependency. Even if any repo doesn’t upgrade themselves to the new version the repos will not start failing as it will continue to use the older parent pom file versions which would be present inside the .mvn folder.