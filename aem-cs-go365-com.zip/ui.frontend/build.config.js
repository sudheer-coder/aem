const { merge }               = require('webpack-merge');
const CssMinimizerPlugin      = require('css-minimizer-webpack-plugin');
const TerserPlugin            = require('terser-webpack-plugin');
const common                  = require('./webpack.common.js');

module.exports = merge(common,{
    mode: 'production',
    optimization: {
        minimize: true,
        minimizer: [
            new TerserPlugin(),
            new CssMinimizerPlugin({
                minimizerOptions:{
                    level: {
                        1: {
                            roundingPrecision: "all=3,px=5",
                        },
                    },
                },
			}),
        ],
        splitChunks: {
            cacheGroups: {
                main: {
                    chunks: 'all',
                    name: 'site',
                    test: 'main',
                    enforce: true
                }
            }
        }
    },
    devtool: false,
    performance: { hints: false }
});