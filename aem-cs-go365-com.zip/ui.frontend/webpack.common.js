'use strict';

const path = require('path');
const webpack = require('webpack');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const TSConfigPathsPlugin = require('tsconfig-paths-webpack-plugin');
const CopyWebpackPlugin = require('copy-webpack-plugin');
const { CleanWebpackPlugin } = require('clean-webpack-plugin');
const { exec } = require('child_process');
const VueLoaderPlugin = require('vue-loader/lib/plugin');
const SOURCE_ROOT = __dirname + '/src/main/webpack';



module.exports = {
    resolve: {
        alias: {
            'vue$': 'vue/dist/vue.esm.js'
        },
        extensions: ['.js', '.ts'],
        plugins: [
            new TSConfigPathsPlugin({
                configFile: './tsconfig.json',
            }),
        ],
    },
    entry: {
        site: SOURCE_ROOT + '/site/main.ts',
    },
    output: {
        filename: (chunkData) => {
            return'clientlib-site/[name].js';
        },
        path: path.resolve(__dirname, 'dist'),
    },
    module: {
        rules: [{
                test: /\.tsx?$/,
                exclude: /node_modules/,
                use: [{
                        options: {
                            eslintPath: require.resolve('eslint'),
                        },
                        loader: require.resolve('eslint-loader'),
                    },
                    {
                        loader: 'ts-loader',
                    },
                    {
                        loader: 'webpack-import-glob-loader',
                        options: {
                            // url: false,
                        },
                    },
                ],
            },
            // {
            //   test: /\.js$/,
            //   exclude: /node_modules/,
            //   loader: 'eslint-loader',
            // },
            {
                test: /\.jsx?$/,
                use: [{ loader: 'babel-loader' }],
                exclude: /node_modules(?:\/|\\)(?!lit-element|lit-html)/
            },
            {
                test: /\.vue$/,
                exclude: '/node_modules/',
                use: [{ loader: 'vue-loader' }]
            },
            {
                test: /\.scss$/,
                use: [
                    MiniCssExtractPlugin.loader,
                    {
                        loader: 'css-loader',
                        options: {
                            url: false,
                        },
                    },
                    {
                        loader: 'postcss-loader',
                        options: {
                            // plugins() {
                            //     return [require('autoprefixer')];
                            // },
                        },
                    },
                    {
                        loader: 'sass-loader',
                        options: {
                            // url: false,
                        },
                    },
                    {
                        loader: 'webpack-import-glob-loader',
                        options: {
                            // url: false,
                        },
                    },
                ],
            },
        ],
    },
    plugins: [
        new CleanWebpackPlugin(),
        new webpack.NoEmitOnErrorsPlugin(),
        new VueLoaderPlugin(),
        new MiniCssExtractPlugin({
            filename: 'clientlib-[name]/[name].css',
        }),
        {
            apply: (compiler) => {
                compiler.hooks.afterEmit.tap('AfterEmitPlugin', (compilation) => {
                    exec('clientlib --verbose');
                });
            },
        },
    ],
    stats: {
        assetsSort: 'chunks',
        builtAt: true,
        children: false,
        chunkGroups: true,
        chunkOrigins: true,
        colors: false,
        errors: true,
        errorDetails: true,
        env: true,
        modules: false,
        performance: true,
        providedExports: false,
        source: false,
        warnings: true,
    },
};