import $ from 'jquery';

class Component {
  constructor(element, selectors) {
    element.removeAttribute('data-cmp-is');

    this.namespace = 'Component';
    this.el = element;
    this.$el = $(element);
    this.$dom = {};
    this.options = { ...this.el.dataset };
    this.selectors = selectors;
  }

  getEventName(event) {
    return `${event}.${this.namespace}`;
  }

  removeDataAttribute() {
    var keys = Object.entries(this.options).map(([key]) => {
      return key;
    });

    for (const key of keys) {
      this.el.removeAttribute(`data-${key}`);
    }
  }


  bindEditorEvent(callback, type) {
    // TODO: This section is only relevant in edit mode and should move to the editor clientLib
    if (
      window.Granite &&
      window.Granite.author &&
      window.Granite.author.MessageChannel
    ) {
      /*
       * Editor message handling:
       * - subscribe to "cmp.panelcontainer" message requests sent by the editor frame
       * - check that the message data panel container type is correct and that the id (path) 
       *   matches this specific Carousel component
       * - if so, route the "navigate" operation to enact a navigation of the Carousel based on index data
       */
      window.CQ = window.CQ || {};
      window.CQ.CoreComponents = window.CQ.CoreComponents || {};
      window.CQ.CoreComponents.MESSAGE_CHANNEL =
        window.CQ.CoreComponents.MESSAGE_CHANNEL ||
        new window.Granite.author.MessageChannel('cqauthor', window);
      window.CQ.CoreComponents.MESSAGE_CHANNEL.subscribeRequestMessage(
        'cmp.panelcontainer',
        (message) => {
          if (
            message.data &&
            message.data.type === type &&
            message.data.id === this.el.dataset['cmpPanelcontainerId']
          ) {
            if (typeof callback === 'function') {
              callback(message);
            }
          }
        }
      );
    }
  }
}

/**
 * Default Options
 */
Component.DEFAULTS = {
  prefixClass: 'gor-',
};

export default Component;
