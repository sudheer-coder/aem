// Best practice:
// Use a method like this mutation obeserver to also properly initialize the component
// when an author drops it onto the page or modified it with the dialog.
export default function initComponent(Component, selectors) {
  function onDocumentReady() {
    var elements = document.querySelectorAll(selectors.self);
    for (var i = 0; i < elements.length; i++) {
      new Component(elements[i], selectors);
    }

    var MutationObserver =
      window.MutationObserver ||
      window.WebKitMutationObserver ||
      window.MozMutationObserver;
    var body = document.querySelector('body');
    var observer = new MutationObserver(function (mutations) {
      mutations.forEach(function (mutation) {
        // needed for IE
        var nodesArray = [].slice.call(mutation.addedNodes);
        if (nodesArray.length > 0) {
          nodesArray.forEach(function (addedNode) {
            if (addedNode.querySelectorAll) {
              var elementsArray = [].slice.call(
                addedNode.querySelectorAll(selectors.self)
              );
              elementsArray.forEach(function (element) {
                new Component(element, selectors);
              });
            }
          });
        }
      });
    });

    observer.observe(body, {
      subtree: true,
      childList: true,
      characterData: true,
    });
  }

  if (document.readyState !== 'loading') {
    onDocumentReady();
  } else {
    document.addEventListener('DOMContentLoaded', onDocumentReady);
  }
}
