(function ($, $document) {
    "use strict";

     // when dialog gets injected
    $(document).on("foundation-contentloaded", function (e) {
        // if there is already an inital value make sure the according target element becomes visible
        Coral.commons.ready(function () {
            showHideTab();
        });
    });

     $(document).on("dialog-ready", function() {	
       $(".cq-dialog-dropdown-showhide").on("change", showHideTab);
       showHideTab();

    });

    function showHideTab() {

        var dropdownSelection = $(".cq-dialog-dropdown-showhide").val();
        var coralTab = $(".collection-tab-container coral-tablist coral-tab");
        if (dropdownSelection === "static") {
            coralTab.eq(2).hide();
        } else {
            coralTab.eq(2).show();
        }
    }

})($, $(document));
