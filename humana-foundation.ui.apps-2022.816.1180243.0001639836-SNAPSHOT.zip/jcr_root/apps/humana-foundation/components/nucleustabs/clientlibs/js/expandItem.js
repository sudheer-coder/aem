(function ($, $document) {


    var tabHeadingInput = document.getElementsByClassName("tab-heading-text");
    var tabHeadingClickToExpand = document.getElementsByClassName('tab-heading-click-to-expand');

    var mainTabInput = document.getElementsByClassName("main-tab-text");
    var mainTabClickToExpand = document.getElementsByClassName("main-tab-click-to-expand");

    var sublinkText = document.getElementsByClassName("sublink-text");
    var sublinkClickToExpand = document.getElementsByClassName("sublink-click-to-expand");


    function textListner(inputField, titleField){

        [].forEach.call(inputField, function(item, i, arr) {
            if ( titleField[i] === undefined ) {
                return;
            }
            var changeTitle = titleField[i].firstChild.children[1];
            changeTitle.innerHTML = item.getAttribute('value');

            const inputHandler = function(e) {
              changeTitle.innerHTML = e.target.value;
            }
            item.addEventListener("input", inputHandler);
            item.addEventListener('propertychange', inputHandler);
        });
    };


	$document.on("dialog-ready", function() {
        textListner(tabHeadingInput, tabHeadingClickToExpand);
        textListner(mainTabInput, mainTabClickToExpand);
        textListner(sublinkText, sublinkClickToExpand);
    });




 })($, $(document));

