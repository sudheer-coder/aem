(function ($, $document) {
    "use strict";

    $(document).on("click", ".cq-dialog-submit", function (e) {
        console.log("submitting");
        let form = $(".cq-dialog");
        let actionUrl = form.attr("action");
        let propertyPath = actionUrl.substring(0, actionUrl.indexOf("_jcr_content")) + "jcr:content/" +
            actionUrl.substring(actionUrl.lastIndexOf("/") + 1, actionUrl.length).replace('article','') + "Component";

		    let dataFrom = document.getElementById('dataFrom');
        if (dataFrom) {
			      let dataFromValue = dataFrom.querySelectorAll('[name="./dataFrom"]')[0].value;
            if(!dataFromValue) {
				        dataFromValue = dataFrom.querySelectorAll('[name="./imageFromPageImage"]')[0].value;
            }
            $('<input/>').attr('type','hidden').attr('name', propertyPath)
            .attr('value', dataFromValue + '~' + actionUrl.split('_jcr_content/')[1]).appendTo(form);
             $('<input/>').attr('type','hidden').attr('name', propertyPath + '@Delete').appendTo(form);
        }
    });

})($, $(document));
