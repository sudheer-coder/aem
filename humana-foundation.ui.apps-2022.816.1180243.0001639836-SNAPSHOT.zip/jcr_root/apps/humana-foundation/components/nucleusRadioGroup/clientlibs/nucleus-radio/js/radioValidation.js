(function ($, $document) {
    $document.on('dialog-ready', () => {
        console.log('dialogReady');
        let radioButtons = {};
        let radioDefaultSelected = '';
        let buttons = document.getElementsByClassName('initially-selected');
    
        let applyListener = function () {
            for ( let i = 0; i < buttons.length; i++ ) {
                buttons[i].addEventListener('click', (e) => {
                    cleanse(e.path[1]);
                })
            }
        }
    
        let buildRadioObject = function () {
            let buttonArray = Array.from(buttons);
            let labels = Array.from(document.getElementsByClassName('radio-label'));
            labels.forEach( (label,i) => {
                radioButtons[label.value] = buttonArray[i].checked;
            })
        }   
    
        let cleanse = function (target) {
            for ( let i = 0; i < buttons.length; i++ ) {
                if ( buttons[i] !== target && buttons[i].checked === true) {
                    buttons[i].checked = false;
                }
            }
        }
    
        console.log('dialogReady');
        buildRadioObject();
        applyListener();
    });
})($, $(document));