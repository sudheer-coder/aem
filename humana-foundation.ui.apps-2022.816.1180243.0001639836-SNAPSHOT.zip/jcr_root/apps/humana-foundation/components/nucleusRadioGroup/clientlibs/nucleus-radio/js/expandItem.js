(function ($, $document) {


    var primaryTextInputs = document.getElementsByClassName("radio-label");
    var clickToExpand = document.getElementsByClassName('radio-click-to-expand');

    function textListner(inputField, titleField){

        [].forEach.call(inputField, function(item, i, arr) {
            var changeTitle = titleField[i].firstChild.children[1];
            changeTitle.innerHTML = item.getAttribute('value');

            const inputHandler = function(e) {
              changeTitle.innerHTML = e.target.value;
            }
            item.addEventListener("input", inputHandler);
            item.addEventListener('propertychange', inputHandler);
        });
    };


	$document.on("dialog-ready", function() {
        textListner(primaryTextInputs, clickToExpand);
    });




 })($, $(document));

