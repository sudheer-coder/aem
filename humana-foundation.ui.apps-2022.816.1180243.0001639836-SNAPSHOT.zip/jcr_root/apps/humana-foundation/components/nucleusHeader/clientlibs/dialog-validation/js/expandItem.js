(function ($, $document) {


    var primaryTextInputs = document.getElementsByClassName("primary-text");
    var clickToExpand = document.getElementsByClassName('click-to-expand');

    var sublinkTextInputs = document.getElementsByClassName("sublink-text");
    var sublinkclickToExpand = document.getElementsByClassName("click-to-expand-sublink");

    var moreSiteTextInputs = document.getElementsByClassName("more-site-text");
    var moreSiteclickToExpand = document.getElementsByClassName("more-site-click-to-expand");

    var languageTextInputs = document.getElementsByClassName("language-text");
    var languageclickToExpand = document.getElementsByClassName("language-click-to-expand");

    var dashboardTextInputs = document.getElementsByClassName("dashboard-text");
    var dashboardclickToExpand = document.getElementsByClassName("dashboard-click-to-expand");

    var superSublinkText = document.getElementsByClassName("super-sublink-text");
    var superSublinkClickToExpand = document.getElementsByClassName("super-sublink-click-to-expand");


    function textListner(inputField, titleField){

        [].forEach.call(inputField, function(item, i, arr) {
            var changeTitle = titleField[i].firstChild.children[1];
            changeTitle.innerHTML = item.getAttribute('value');

            const inputHandler = function(e) {
              changeTitle.innerHTML = e.target.value;
            }
            item.addEventListener("input", inputHandler);
            item.addEventListener('propertychange', inputHandler);
        });
    };


	$document.on("dialog-ready", function() {


        textListner(primaryTextInputs, clickToExpand);
        textListner(sublinkTextInputs, sublinkclickToExpand);
        textListner(moreSiteTextInputs, moreSiteclickToExpand);
        textListner(languageTextInputs, languageclickToExpand);
        textListner(dashboardTextInputs, dashboardclickToExpand);
        textListner(superSublinkText, superSublinkClickToExpand);

    });




 })($, $(document));

